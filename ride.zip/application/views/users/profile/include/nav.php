<?php include_once('top_menu.php'); ?>
<div class="container main bg-main">	
<?php include_once('right_menu.php'); ?>