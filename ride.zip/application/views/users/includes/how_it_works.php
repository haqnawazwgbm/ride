<section id="how-work">
    <div class="container">
        <h3>How it works</h3>
        <div class="row">
            <div class="col-md-4"><!-- col -->
                <h4>1- Going Somewhere?</h4>
                <p>Find people who travel on the same route</p>
            </div>
            <div class="col-md-4"><!-- col -->
                <h4>1- Going Somewhere?</h4>
                <p>Find people who travel on the same route</p>
            </div>
            <div class="col-md-4"><!-- col -->
                <h4>1- Going Somewhere?</h4>
                <p>Find people who travel on the same route</p>
            </div>
        </div><!-- row -->
        <div class="col-lg-12">
            <img src="http://localhost/ride/assets/images/car3.jpeg" style="max-height: 300px; width: 100%;" alt="Not Found" class="img-responsive">
        </div>
    </div><!-- container -->
</section><!-- how-work --> 