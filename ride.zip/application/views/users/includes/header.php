<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Fazal Maula Jan</title>


</head>
<body id="signup-bg">
<?php include_once 'nav.php'; ?>
<?php include_once 'css.php'; ?>
<?php include 'js.php'; ?>
<?php include_once 'login.php'; ?>