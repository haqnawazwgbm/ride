<footer>
	<div class="container">
		<p>&copy 2017 blabla.com All rights reserved</p>
	</div><!-- container -->
</footer><!-- footer -->