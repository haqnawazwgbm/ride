<section id="larg-footer">
	<div class="container">
		<div class="row">
			<div class="col-md-3">
				<h4>Using BlaBlaCar</h4>
				<p><a href="">How It Works</a></p>
				<p><a href="">Trust & Safety</a></p>
				<p><a href="">Experience Levels</a></p>
				<p><a href="">Ratings</a></p>
				<p><a href="">Ladies only</a></p>
				<p><a href="">Member's Agreement</a></p>
				<p><a href="">Frequently Asked Questions</a></p>
			</div><!-- col -->
			<div class="col-md-3">
				<h4>Our Company</h4>
				<p><a href="">How It Works</a></p>
				<p><a href="">Trust & Safety</a></p>
				<p><a href="">Experience Levels</a></p>
				<p><a href="">Ratings</a></p>
				<p><a href="">Ladies only</a></p>
			</div><!-- col -->
			<div class="col-md-3">
				<h4>Legal</h4>
				<p><a href="">Terms & Conditions</a></p>
				<p><a href="">Policy Privacy</a></p>
				<p><a href="">Cookies Policy</a></p>
				
			</div><!-- col -->
			<div class="col-md-3">
				<h4>Download</h4>
				<span class="app"><a href=""><i class="fa fa-android fa-2x" style="color:#7AC157"></i> Google Play</a></span>
				<span class="app"><a href=""><i class="fa fa-apple fa-2x" style="color:#EFEEF3;"></i> App Store</a></span>
				<br><br>
				<span class="social"><a href=""><i class="fa fa-facebook"></i></a></span>
				<span class="social"><a href=""><i class="fa fa-twitter"></i></a></span>
				<span class="social"><a href=""><i class="fa fa-linkedin"></i></a></span>
				<span class="social"><a href=""><i class="fa fa-youtube"></i></a></span>
			</div><!-- col -->
		</div><!-- row -->
	</div><!-- container -->
</section><!-- larg-footer -->